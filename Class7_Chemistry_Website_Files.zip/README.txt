Upload index.html and the pdfs folder to GitHub Pages.
Keep filenames unchanged.